package com.monze.mysqlpostgresql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysqlpostgresqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(MysqlpostgresqlApplication.class, args);
	}

}
